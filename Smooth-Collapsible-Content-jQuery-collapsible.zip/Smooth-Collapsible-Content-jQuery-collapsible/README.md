# jquery-collapsible
Simple collapsible plugin
